---
name: Cinematic Obsidian
colors:
  surface: '#131313'
  surface-dim: '#131313'
  surface-bright: '#393939'
  surface-container-lowest: '#0e0e0e'
  surface-container-low: '#1c1b1b'
  surface-container: '#201f1f'
  surface-container-high: '#2a2a2a'
  surface-container-highest: '#353534'
  on-surface: '#e5e2e1'
  on-surface-variant: '#e9bcb6'
  inverse-surface: '#e5e2e1'
  inverse-on-surface: '#313030'
  outline: '#af8782'
  outline-variant: '#5e3f3b'
  surface-tint: '#ffb4aa'
  primary: '#ffb4aa'
  on-primary: '#690003'
  primary-container: '#e50914'
  on-primary-container: '#fff7f6'
  inverse-primary: '#c0000c'
  secondary: '#ffb4a8'
  on-secondary: '#690000'
  secondary-container: '#920703'
  on-secondary-container: '#ff9a8a'
  tertiary: '#b0c6ff'
  on-tertiary: '#002d6e'
  tertiary-container: '#066bf1'
  on-tertiary-container: '#f9f8ff'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#ffdad5'
  primary-fixed-dim: '#ffb4aa'
  on-primary-fixed: '#410001'
  on-primary-fixed-variant: '#930007'
  secondary-fixed: '#ffdad4'
  secondary-fixed-dim: '#ffb4a8'
  on-secondary-fixed: '#410000'
  on-secondary-fixed-variant: '#920703'
  tertiary-fixed: '#d9e2ff'
  tertiary-fixed-dim: '#b0c6ff'
  on-tertiary-fixed: '#001945'
  on-tertiary-fixed-variant: '#00429b'
  background: '#131313'
  on-background: '#e5e2e1'
  surface-variant: '#353534'
typography:
  display-hero:
    fontFamily: Plus Jakarta Sans
    fontSize: 56px
    fontWeight: '800'
    lineHeight: 64px
    letterSpacing: -0.03em
  display-hero-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 36px
    fontWeight: '800'
    lineHeight: 44px
    letterSpacing: -0.02em
  headline-xl:
    fontFamily: Plus Jakarta Sans
    fontSize: 40px
    fontWeight: '700'
    lineHeight: 48px
    letterSpacing: -0.02em
  headline-xl-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 28px
    fontWeight: '700'
    lineHeight: 36px
    letterSpacing: -0.01em
  headline-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
    letterSpacing: -0.015em
  headline-lg-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 24px
    fontWeight: '700'
    lineHeight: 32px
    letterSpacing: -0.01em
  headline-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 22px
    fontWeight: '600'
    lineHeight: 28px
    letterSpacing: -0.01em
  headline-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 18px
    fontWeight: '600'
    lineHeight: 24px
  body-lg:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 26px
  body-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 22px
  body-sm:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 18px
  label-md:
    fontFamily: Inter
    fontSize: 13px
    fontWeight: '600'
    lineHeight: 18px
    letterSpacing: 0.02em
  label-sm:
    fontFamily: Inter
    fontSize: 11px
    fontWeight: '700'
    lineHeight: 14px
    letterSpacing: 0.06em
  metric-rank:
    fontFamily: Plus Jakarta Sans
    fontSize: 120px
    fontWeight: '900'
    lineHeight: 100px
    letterSpacing: -0.05em
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  gutter: 1.5rem
  gutter-mobile: 0.75rem
  margin: 3rem
  margin-tablet: 2rem
  margin-mobile: 1rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2.5rem
---

## Brand & Style

The design system embraces a **Cinematic Dark Minimalist** aesthetic engineered specifically for high-fidelity visual media consumption and curated digital art libraries. It evokes the sensory gravitas of flagship streaming interfaces and premium gallery curation: deep obsidian canvases, focused luminescent accents, disciplined typography, and high-impact visual staging.

### Brand Personality & Emotional Intent
- **Cinematic & Immersive:** Interface chrome recedes into deep charcoal values, allowing visual art pieces and ultra-high-definition wallpapers to be the hero elements.
- **Focused & Decisive:** Actions are distinct and deliberate. Crimson kinetic accents drive discovery, curation, and ownership flows.
- **Curated & Authoritative:** Typography strikes a balance between editorial prestige and utilitarian clarity, treating every wallpaper as a featured cinematic release.

### Visual Architecture
The style pairs frosted glassmorphic navigational headers and structural card surfaces with razor-sharp metadata tags and glowing micro-gradients. High-contrast typographic ranking elements introduce energetic editorial pacing across dense media grids.

## Colors

The color palette is built on a high-depth obsidian foundation with high-energy cinematic crimson highlights, supported by clear informational signals for media resolutions and states.

### Core Roles
- **Primary (`#E50914`):** Cinematic Crimson. Reserved for primary calls-to-action, key selection states, download triggers, and hero spotlight badges.
- **Secondary (`#8B0000`):** Deep Burgundy. Used in dynamic gradient tapers (`#E50914` to `#8B0000`), hover transitions on dark surfaces, and background glows behind featured cards.
- **Tertiary (`#2979FF`):** Electric Cobalt. Assigned to technical metadata (e.g., resolution attributes like 4K/8K, system updates, and info badges).
- **Success (`#00C853`):** Vivid Emerald. Exclusively for successful operations (e.g., saved states, live synchronization, active status badges).
- **Neutral Canvas (`#141414`):** Pure charcoal base, preventing the stark eye-strain of pure `#000000` while preserving absolute dynamic range for rich HDR and OLED content.

### Surface Tiers
- **Canvas Base:** `#141414`
- **Surface Level 1 (Sections / Sidebars):** `#1A1A1A`
- **Surface Level 2 (Cards / Panels):** `#242424` with borders tinted to `#333333`
- **Surface Level 3 (Modals / Overlays):** `rgba(36, 36, 36, 0.85)` with `backdrop-filter: blur(20px)`
- **Text & Content Contrast:**
  - High Emphasis: `#FFFFFF`
  - Medium Emphasis: `#B3B3B3`
  - Low Emphasis / Disabled: `#808080`

## Typography

Typography establishes an editorial rhythm suited for visual discovery. 

- **Headlines & Display:** Set in **Plus Jakarta Sans**, utilizing heavy font weights (600–800) with tight, crisp negative letter tracking. This delivers cinematic authority to collection names, platform metrics, and hero spotlight headlines.
- **Body & Labels:** Set in **Inter**, guaranteeing high legibility across dense dashboard grids, micro-badges (4K, 8K, OLED), author attribution lines, and technical specification tags.
- **Top 10 Display Numbering (`metric-rank`):** Giant outlined glyphs inspired by modern streaming interfaces. These characters utilize a transparent fill with a 2px text stroke (`#404040` default, active `#E50914`) to anchor horizontal discovery rows.

## Layout & Spacing

The platform uses a dynamic **fluid grid system** that adapts strictly across three standard device categories:

### Breakpoints & Grid Rules
- **Desktop (1200px+):** 12-column layout, `3rem` margins, `1.5rem` gutters. Poster cards typically occupy 2, 3, or 4 columns (6-up, 4-up, or 3-up configurations).
- **Tablet (768px – 1199px):** 8-column layout, `2rem` margins, `1rem` gutters. Media grids condense to 2-up or 3-up poster formats.
- **Mobile (<768px):** 4-column layout, `1rem` margins, `0.75rem` gutters. Media displays default to 2-column masonry or full-bleed horizontal scroll carousels.

### Component Spacing Discipline
Spacing inside elements strictly follows consistent increments:
- `space-xs` (4px): Internal badge padding and tight metadata icon offsets.
- `space-sm` (8px): Gaps between micro-chips, action button icon gaps, and input row padding.
- `space-md` (16px): Internal poster padding, standard card margins, and modal internal headers.
- `space-lg` (24px): Separation between section headers and visual grids.
- `space-xl` (40px): Section-to-section baseline rhythm across discovery views.

## Elevation & Depth

Visual hierarchy does not rely on heavy drop shadows, but on **translucent surface stacking, low-contrast luminous borders, and atmospheric ambient glows**.

### Depth Layers
- **Level 0 (Canvas Base):** Solid `#141414`. Flat foundation.
- **Level 1 (Docked Sidebars & Rails):** `#1A1A1A` with a 1px solid border of `rgba(255, 255, 255, 0.05)`.
- **Level 2 (Posters & Content Panels):** `#242424` with a 1px hairline border of `#333333`. Upon hover, cards lift along the Z-axis using `transform: scale(1.04)` accompanied by a subtle ambient shadow: `0 12px 32px rgba(0, 0, 0, 0.6)`.
- **Level 3 (Sticky Headers & Navigation):** `rgba(20, 20, 20, 0.75)` backdrop blur with `backdrop-filter: blur(24px)` and a bottom border of `rgba(255, 255, 255, 0.08)`.
- **Level 4 (Modals, Lightboxes & Dropdowns):** `rgba(26, 26, 26, 0.94)` with `backdrop-filter: blur(32px)`, bordered by `rgba(255, 255, 255, 0.12)`, anchored by an elevated atmospheric drop shadow: `0 24px 64px rgba(0, 0, 0, 0.8)`.

### Accent Lighting
Interactive elements, such as primary action buttons or spotlight cards, receive an ambient radial underglow using the primary brand gradient (`rgba(229, 9, 20, 0.25)` blurring outward to 24px), providing a cinematic projection effect.

## Shapes

The design system maintains a modern, disciplined corner geometry: `Soft` (Option 1). Sharp enough to convey technical precision, yet softened to harmonize with digital imagery.

### Corner Radii Guidelines
- **Core Elements (`0.25rem` / 4px):** Badges (4K, OLED), input fields, dropdown menus, micro-action buttons, table cells.
- **Cards & Surfaces (`0.5rem` / 8px):** Poster cards, preview frames, collection stacks, settings cards.
- **Hero & Modal Elements (`0.75rem` / 12px):** Detail modals, quick-view lightboxes, featured collection hero banners.
- **Specialized Rounding:** Filter pills and status indicators intentionally break the base rule and use full pill caps (`9999px`) to distinguish interactive classification controls from content containers.

## Components

### 1. Poster-Style Wallpaper Cards
- **Geometry & Structure:** Standard aspect ratios of 9:16 (mobile wallpapers) or 16:9 (desktop). Base background `#242424` with a 1px border of `#333333`. Corner radius `0.5rem`.
- **Micro-Badges:** Positioned at top-left: resolution badges (`4K`, `8K`, `OLED`) with `11px` uppercase Inter bold text, dark glass backplate (`rgba(0, 0, 0, 0.65)`), and electric blue/white accents.
- **Hover Micro-Interactions:** 
  - Card scales up to `1.04` with ease-out timing (`250ms`).
  - Dark gradient overlay fades in at bottom (`rgba(0, 0, 0, 0.8)` to transparent).
  - Floating action buttons emerge at top-right: Quick Favorite (heart icon), Add to Collection (plus icon), and Quick Download (arrow icon). Action buttons are circular (`36px`), styled in `rgba(30, 30, 30, 0.85)` glass with white icon fills.

### 2. Netflix-Inspired Top 10 Ranks
- Horizontal carousel featuring oversized typographic numbers positioned partially behind or flush beside the poster cards.
- **Typography:** `metric-rank` (120px) styled with transparent fill, `2px` webkit text stroke `#383838`, transitioning to `#E50914` stroke when the associated card is active or hovered.

### 3. Glassmorphic Navigation Header
- Fixed/sticky bar with dynamic opacity: completely transparent at top of scroll, transitioning to `rgba(20, 20, 20, 0.85)` with `24px` backdrop blur upon 50px downward scroll.
- Includes integrated cinematic search input with subtle crimson focus border, category jump links, and user collection profile avatar.

### 4. Pill-Style Filter Tags & Category Cards
- **Filter Tags:** Full pill shape (`9999px`), `rgba(255, 255, 255, 0.08)` surface, `13px` Inter Medium typography. Active state turns to solid Crimson (`#E50914`) with bold white text.
- **Category Tiles:** Low-profile aspect ratio containers featuring low-opacity artistic wallpaper backdrops, darkened with a gradient overlay (`#141414` at 60%), centered with high-contrast Jakarta Sans headlines.

### 5. Buttons & Controls
- **Primary Button:** Background gradient `#E50914` to `#8B0000`, crisp `#FFFFFF` typography, `0.25rem` radius, subtle crimson drop shadow on hover.
- **Secondary Button:** Surface `#242424`, border `#333333`, hover state elevates to `#2E2E2E` with white border transition.
- **Checkboxes & Radios:** Minimalist square/circular indicators, `#1A1A1A` fill, `#333333` border; active states fill with `#E50914` featuring an ultra-crisp white vector tick.

### 6. Admin & Curation Dashboard Rows
- **Metrics Panels:** Single-metric cards with subtle charcoal backgrounds, Jakarta Sans statistics, and mini trend indicators.
- **Table Rows:** Hoverable list rows with subtle border separators (`rgba(255, 255, 255, 0.04)`), featuring thumbnail previews, resolution metrics, and download frequency numbers.
- **Status Badges:**
  - *Featured:* Deep crimson pill with glowing red text (`#E50914`).
  - *Active:* Forest emerald pill with green text (`#00C853`).
  - *Archived:* Muted charcoal pill with gray text (`#808080`).

### 7. Collection Cover Stacks & Download Modals
- **Collection Cover Stack:** Visual stack effect using 3 offset layered cards behind the main cover, creating physical visual depth for grouped wallpaper packs.
- **ZIP Download Modal:** Centered dialog, `backdrop-filter: blur(32px)`, presenting single-click bulk resolution selectors (e.g., "Download All (5K Uncompressed) - 340 MB") alongside progress bar visualization in brand crimson.